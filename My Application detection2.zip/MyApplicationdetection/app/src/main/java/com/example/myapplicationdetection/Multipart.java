package com.example.myapplicationdetection;

public @interface Multipart {
}
