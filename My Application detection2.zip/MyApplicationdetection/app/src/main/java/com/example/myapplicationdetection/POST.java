package com.example.myapplicationdetection;

public @interface POST {
}
